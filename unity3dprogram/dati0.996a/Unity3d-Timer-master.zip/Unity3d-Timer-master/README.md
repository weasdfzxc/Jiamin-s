Unity3d-Timer
=============

Just a time manager , so easy .

Too simple, so I do not need to explain, just see the code. 

Help yourself. 

How to use see the TimeManager.cs ~

Yooooooo~~~
